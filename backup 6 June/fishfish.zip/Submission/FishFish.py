#MeerKat & Sprite

from PyQt4 import QtCore, QtGui
from os import system, name
import binascii, sys, hashlib, time

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName(_fromUtf8("Form"))
        Form.resize(517, 312)
        self.lblInputfile = QtGui.QLabel(Form)
        self.lblInputfile.setGeometry(QtCore.QRect(20, 30, 66, 17))
        self.lblInputfile.setObjectName(_fromUtf8("lblInputfile"))
        self.txtInputfile = QtGui.QTextEdit(Form)
        self.txtInputfile.setGeometry(QtCore.QRect(20, 50, 421, 21))
        self.txtInputfile.setObjectName(_fromUtf8("txtInputfile"))
        self.btnBrowse = QtGui.QPushButton(Form)
        self.btnBrowse.setGeometry(QtCore.QRect(450, 50, 31, 21))
        self.btnBrowse.setObjectName(_fromUtf8("btnBrowse"))
        self.label_2 = QtGui.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(20, 90, 66, 17))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.txtPassword = QtGui.QTextEdit(Form)
        self.txtPassword.setGeometry(QtCore.QRect(20, 110, 141, 21))
        self.txtPassword.setObjectName(_fromUtf8("txtPassword"))
        self.radEncrypt = QtGui.QRadioButton(Form)
        self.radEncrypt.setGeometry(QtCore.QRect(70, 180, 114, 22))
        self.radEncrypt.setObjectName(_fromUtf8("radEncrypt"))
        self.radDecrypt = QtGui.QRadioButton(Form)
        self.radDecrypt.setGeometry(QtCore.QRect(70, 230, 114, 22))
        self.radDecrypt.setObjectName(_fromUtf8("radDecrypt"))
        self.btnRun = QtGui.QPushButton(Form)
        self.btnRun.setGeometry(QtCore.QRect(300, 190, 111, 71))
        self.btnRun.setObjectName(_fromUtf8("btnRun"))
        self.decGroup = QtGui.QGroupBox(Form)
        self.decGroup.setGeometry(QtCore.QRect(180, 90, 311, 80))
        self.decGroup.setObjectName(_fromUtf8("decGroup"))
        self.radTxt = QtGui.QRadioButton(self.decGroup)
        self.radTxt.setGeometry(QtCore.QRect(20, 30, 51, 22))
        self.radTxt.setObjectName(_fromUtf8("radTxt"))
        self.radRar = QtGui.QRadioButton(self.decGroup)
        self.radRar.setGeometry(QtCore.QRect(120, 30, 61, 22))
        self.radRar.setObjectName(_fromUtf8("radRar"))
        self.radPng = QtGui.QRadioButton(self.decGroup)
        self.radPng.setGeometry(QtCore.QRect(220, 30, 61, 22))
        self.radPng.setObjectName(_fromUtf8("radPng"))

        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        Form.setWindowTitle(_translate("Form", "Form", None))
        self.lblInputfile.setText(_translate("Form", "Input file:", None))
        self.btnBrowse.setText(_translate("Form", "...", None))
        self.label_2.setText(_translate("Form", "Password:", None))
        self.radEncrypt.setText(_translate("Form", "Encrypt", None))
        self.radDecrypt.setText(_translate("Form", "Decrypt", None))
        self.btnRun.setText(_translate("Form", "...", None))
        self.decGroup.setTitle(_translate("Form", "", None))
        self.radTxt.setText(_translate("Form", ".txt", None))
        self.radRar.setText(_translate("Form", ".rar", None))
        self.radPng.setText(_translate("Form", ".png", None))

################################################################################
#MeerKat & Sprite
        self.btnBrowse.clicked.connect(lambda: browseFiles())
        self.btnRun.setEnabled(False)
        self.radDecrypt.clicked.connect(lambda: dec())
        self.radEncrypt.clicked.connect(lambda: Enc())
        self.btnRun.clicked.connect(lambda: runProgram())
        self.radTxt.setEnabled(False)
        self.radRar.setEnabled(False)
        self.radPng.setEnabled(False)
        self.radTxt.clicked.connect(lambda: decTo())
        self.radRar.clicked.connect(lambda: decTo())
        self.radRar.clicked.connect(lambda: decTo())

#The four 8bit by 8bit keydependant sboxes that is used in twofish
#Receives a 128bit hashed key and a 32bit plaintext
#Returns a 32bit chiper text
def Sbox(key, value): #Flag: Might not be 100% right, might cuase logic errors in decrypting
    try:
        sub = getSubkeys(key) #password
        sub1 = sub[:8]
        sub2 = sub[8:]
        a = "0101"
        b = "0011"
        c = "1010"
        for i in range(0,3):
            if (i == 1):
                sub1 = sub2
                a = b
            elif (i == 2):
                a = c
            b1 = permutate(value[:2],a[0])
            b2 = permutate(value[2:4],a[1])
            b3 = permutate(value[4:6],a[2])
            b4 = permutate(value[6:8],a[3])
            if (i < 2):
                value = xor(sub1, (b1 + b2 + b3 + b4))
        return b1 + b2 + b3 + b4
    except (ValueError, TypeError) as Error:
        print("Sbox: ")
        print(Error)

#Multiplies two hexadecimal strings inside the Galois field with the primitive polynomial
#Polynomial to use for MDS matrix:           x^8 + x^6 + x^5 + x^3 + 1
#Polyomial to use for creating the subkeys:  x^8 + x^6 + x^3 + x^2 + 1
def GFMultiply(hex1,hex2,polynomial):
    try:
        hex1 = binToDec(hexToBin(hex1))
        hex2 = hexToBin(hex2)
        high = 0
        ans = ""
        nums = []
        for a in range(0,len(hex2)): #Get values to multiply with
            if (hex2[a] == "1"):
                nums.append(str(2**(len(hex2)-1-a)))
        for b in range(0,len(nums)): #Get products in binary
            nums[b] = str(decToBin(hex1 * int(nums[b])))
            if (len(nums[b]) > high):
                high = len(nums[b])
        for c in range(0,len(nums)): #Make binary products equal length
            while (len(nums[c]) < high):
                nums[c] = "0" + nums[c]
        ans = nums[0]
        if (len(nums) > 1):
            for d in range(1,len(nums)): #Xor all the products
                ans = xor(ans,nums[d])
        while (len(ans) >= len(polynomial)): #Modulate ans with the polynomial
            mod = polynomial
            while (len(mod) < len(ans)):
                mod += "0"
            ans = xor(ans,mod)
            ans = str(int(ans))
        while (len(ans)%4 != 0):
            ans = "0" + ans
        if (len(ans) == 4):
            ans = "0000" + ans
        return binToHex(ans)
    except (ValueError, TypeError) as error:
        print("GFMultiply:")
        print(error)

#Permutations of the Sbox
#Input: a hexadecimal input string(4combit) and a int value indicating wether it should use table q0 or q1
#Output: a shuffled hexadecimal string(4bit)
def permutate(inHex,n):
    try:
        q0t0 = ['8','1','7','d','6','f','3','2','0','b','5','9','e','c','a','4']
        q0t1 = ['e','c','b','8','1','2','3','5','f','4','a','6','7','0','9','d']
        q0t2 = ['b','a','5','e','6','d','9','0','c','8','f','3','2','4','7','1']
        q0t3 = ['d','7','f','4','1','2','6','e','9','b','3','0','8','5','c','a']
        q1t0 = ['2','8','b','d','f','7','6','e','3','1','9','4','0','a','c','5']
        q1t1 = ['1','e','2','b','4','c','3','7','6','d','a','5','f','9','0','8']
        q1t2 = ['4','c','7','5','1','6','9','a','0','e','d','8','2','b','3','f']
        q1t3 = ['b','9','5','1','c','3','d','e','6','4','7','f','2','0','8','a']
        a = inHex[0]
        b = inHex[1]
        for i in range(0,2):
            newA = xor(a,b)
            newB = xor(xor(a,rotateValue(b,1)),modulate(a))
            if (n == 0):
                if (i == 0):
                    a = q0t0[hexToDec(newA)]
                    b = q0t1[hexToDec(newB)]
                else:
                    a = q0t2[hexToDec(newA)]
                    b = q0t3[hexToDec(newB)]
            else:
                if (i == 0):
                    a = q1t0[hexToDec(newA)]
                    b = q1t1[hexToDec(newB)]
                else:
                    a = q1t2[hexToDec(newA)]
                    b = q1t3[hexToDec(newB)]
        return a + b
    except (ValueError, TypeError) as error:
        print("Permutate:")
        print(error)

#8(hexChar) mod 16
def modulate(hexChar):
    try:
        num = hexToDec(hexChar)
        num = ((8*num)%16)
        return decToHex(num)
    except (ValueError, TypeError) as error:
        print("Modulate:")
        print(error)

#Change a binary string to a hexadecimal string
def binToHex(bi):
    try:
        return '%0*X' % ((len(bi) + 3) // 4, int(bi, 2))
    except (ValueError, TypeError) as Error:
        print("binToHex:")
        print(Error)

#Change a hexadecimal string to a binary string
def hexToBin(hex):
    try:
        ans = bin(int(hex,16))[2:]
        while (len(ans)%(4*len(hex)) != 0):
            ans = "0" + ans
        return ans
    except (ValueError, TypeError) as error:
        print("hexToBin:")
        print(error)

#Change hexadecimalal string to a decimal number
def hexToDec(hex):
    num = hexToBin(hex)
    num = binToDec(num)
    return num

#Change a binary string to a decimal number
def binToDec(bin):
    try:
        return int(bin,2)
    except (ValueError, TypeError) as error:
        print("binToDec:")
        print(error)

#Change an integer to hexadecimal
def decToHex(n):
    try:
        return binToHex(decToBin(n))
    except (ValueError, TypeError) as Error:
        print("decToHex:")
        print(Error)

#Change a decimal number to a binary string
def decToBin(num):
    try:
        b = bin(num)[2:]
        while (len(b)%4 != 0):
            b = "0" + b
        return b
    except (ValueError, TypeError) as error:
        print("decToBin:")
        print(error)

#Xor two string hex values and return the binary result
def xor(i, p):
    try:
        ans = ""
        while (len(i) != len (p)):
            if (len(i) < len(p)):
                i = "0" + i
            elif (len(i) > len(p)):
                p = "0" + p
        ans = decToHex(int(i,16)^int(p,16))
        while(len(ans) != len(i)):
            ans = "0" + ans
        return ans
    except (ValueError, TypeError) as error:
        print("xor:")
        print(error)

#Get Key: Returns a 128-bit hashed password key
def hash(p):
    key = hashlib.md5(p)
    return key.hexdigest()

#Generates the subkeys for the key
#Input: 128bit Key
#Output: 64bit Subkey
def getSubkeys(key):
    try:
        s = ""
        rs0 = ["01","a4","55","87","5a","58","db","9e"]
        rs1 = ["a4","56","82","f3","1e","c6","68","e5"]
        rs2 = ["02","a1","fc","c1","47","ae","3d","19"]
        rs3 = ["a4","55","87","5a","58","db","9e","03"]
        for a in range(0,2):
            k = key[:16]
            key = key[16:]
            for b in range(0,4):
                newK = k
                sub = ""
                if (b == 0):
                    rs = rs0
                elif (b == 1):
                    rs = rs1
                elif (b == 2):
                    rs = rs2
                elif (b == 3):
                    rs = rs3
                for c in range(0,8):
                    current = newK[:2]
                    newK = newK[2:]
                    product = GFMultiply(current,rs[c],"101001101")
                    if (c == 0):
                        sub = product
                    elif (c > 0):
                        sub = xor(sub,product)
                s += sub
        return s
    except (ValueError, TypeError) as error:
        print("getSubkeys:")
        print(error)

#Multiplies a 32bit value with the mds matrix
def mds(p): #Flag: Might not be 100% right
    ms0 = ["01","ef","5b","5b"] #5b x 49 = 1
    ms1 = ["5b","ef","ef","01"] #ef x 89 = 1
    ms2 = ["ef","5b","01","ef"]
    ms3 = ["ef","01","ef","5b"]
    newP = ""
    finalAns = ""
    for a in range(0,4):
        newP += p[6-(a*2):]
        p = p[:6-(a*2)]
    ms = ms0
    for b in range(0,4):
        if (b == 1):
            ms = ms1
        elif (b == 2):
            ms = ms2
        elif (b == 3):
            ms = ms3
        ans = ""
        getP = newP
        for c in range(0,4):
            current = getP[:2]
            getP = getP[2:]
            ans = GFMultiply(current,ms[c],"101101001")
            #print(current + ", " + ms[c] + ", " + ans)
            if (c == 0):
                newAns = ans
            elif (c > 0):
                newAns = xor(newAns,ans)
        finalAns += newAns
    return finalAns

def bruteForceInv(val, pol):
    inverse = ""
    for i in range(0,256):
        ans = GFMultiply(decToHex(i),val,pol)
        if (ans == "01"):
            inverse = decToHex(i)
    return inverse

#Psuedo-Hadamard Transform: Recieces two 32bit hexadecimal string values and returns the sum modulo 2^32
#Example of implemantation: x = PHTransform(binToHex(xor("8a3333a8","8a3333a8")),"abcdef12")
def PHTransform(a, b):
    ans = xor(hexToBin(a),hexToBin(b))
    polynomial = decToBin(2**32)
    while (len(ans) >= len(polynomial)): #Modulate ans with the polynomial
        mod = polynomial
        while (len(mod) < len(ans)):
            mod += "0"
        ans = xor(ans,mod)
        ans = str(int(ans))
    while (len(ans)%4 != 0):
        ans = "0" + ans
    if (len(ans) == 4):
        ans = "0000" + ans
    return binToHex(ans)

def encryptFile(plain):
    cipherText = ""
    while (len(plain)%32 != 0):
        plain += "0"
    password = ui.txtPassword.toPlainText()
    key = ""
    passw = hash(password)
    for a in range(0,10):
        key += hash(password)
    cnt = len(plain)
    r = -10
    progress = "Encrypting File: " + ui.txtInputfile.toPlainText() + "\nWorking"
    timer = time.time()
    for b in range(0,cnt/32): #Encrypts plaintext 128bits at a time
        _ = system('clear')
        if (b%10 == 0):
            r += 10
        print(progress + "." * (b-r))
        curKey = key[64:]
        #Input Whitening
        t0 = xor(plain[:8],key[:8])
        t1 = xor(plain[8:16],key[8:16])
        t2 = xor(plain[16:24],key[16:24])
        t3 = xor(plain[24:32],key[24:32])
        for c in range(0,16): #Start round of encryption
            #Save origenal values to swap with t2 and t3 later
            saveT0 = t0
            saveT1 = t1
            #Put values through sboxes and mds matrix
            t0 = mds(Sbox(passw,t0))
            t1 = mds(Sbox(passw,rotateValue(t1,-8)))
            #Put values through PHT and add keys from key schedule to values
            newT1 = t0
            t0 = PHTransform(PHTransform(t0,t1),curKey[:8])
            curKey = curKey[8:]
            t1 = PHTransform(newT1,curKey[:8])
            curKey = curKey[8:]
            #Xor and rotate appropraite values
            t2 = xor(t0,t2)
            t2 = rotateValue(t2,1)
            t3 = rotateValue(t3,-1)
            t3 = xor(t1,t3)
            #Swap for next round
            t0 = t2
            t1 = t3
            t2 = saveT0
            t3 = saveT1
        #Undo last swap
        saveT0 = t0
        saveT1 = t1
        t0 = t2
        t1 = t3
        t2 = saveT0
        t3 = saveT1
        plain = plain[32:]
        #Output Whitening
        t0 = xor(t0,key[32:40])
        t1 = xor(t1,key[40:48])
        t2 = xor(t2,key[48:56])
        t3 = xor(t3,key[56:64])
        #Add to cipherText
        cipherText += t0 + t1 + t2 + t3
    filename = ui.txtInputfile.toPlainText()
    msg = QtGui.QMessageBox()
    msg.setText("The file " + filename + " has succesfully been Encrypted!")
    while (filename[len(filename)-1] != "."):
        filename = filename[:len(filename)-1]
    filename += "dec"
    f = open(filename, 'wb')
    f.write(binascii.unhexlify(cipherText))
    f.close()
    print("File Encrypted in " + str(time.time()-timer) + " seconds")
    msg.exec_()

def decryptFile(cipher):
    print("Decrypt")

#Run main program
def runProgram():
    msg = QtGui.QMessageBox()
    try:
        filename = ui.txtInputfile.toPlainText()
        with open(filename, 'rb') as f:
            plaintext = binascii.hexlify(f.read())
        f.close()
        if (ui.btnRun.text() == "Encrypt"):
            encryptFile(plaintext)
        elif (ui.btnRun.text() == "Decrypt"):
            decryptFile(plaintext)
    except (IOError) as error:
        msg.setText("Please make sure to select a file first.")
        msg.exec_()

#Rotate a binary string a predetermined value to the left or right
#Input: a hexadecimal string value to shift and an int value indicating wether to shift right(1) or left(-1)
def rotateValue(h, shift):
    try:
        rotBin = hexToBin(h)
        for i in range(0,4-len(rotBin)):
            rotBin = "0" + rotBin
        Lfirst = rotBin[0 : shift]
        Lsecond = rotBin[shift : ]
        Rfirst = rotBin[0 : len(rotBin)-shift]
        Rsecond = rotBin[len(rotBin)-shift : ]
        return str(binToHex(Lsecond + Lfirst))
    except (ValueError, TypeError) as error:
        print("rotateValue:")
        print(error)

#Test conditions to enable btn Run
def testConditions():
    met = True
    if (ui.txtInputfile.toPlainText() == ""):
        met = False
    elif (ui.txtPassword.toPlainText() == ""):
        met = False
    if (met):
        ui.btnRun.setEnabled(True)

def Enc():
    ui.radTxt.setEnabled(False)
    ui.radTxt.setCheckable(False)
    ui.radTxt.setCheckable(True)
    ui.radRar.setEnabled(False)
    ui.radRar.setCheckable(False)
    ui.radRar.setCheckable(True)
    ui.radPng.setEnabled(False)
    ui.radPng.setCheckable(False)
    ui.radPng.setCheckable(True)
    ui.decGroup.setTitle("")
    ui.btnRun.setText("Encrypt")
    testConditions()

def dec():
    ui.btnRun.setEnabled(False)
    ui.decGroup.setTitle("Decrypt file to:")
    ui.radTxt.setEnabled(True)
    ui.radRar.setEnabled(True)
    ui.radPng.setEnabled(True)

def decTo():
    ui.btnRun.setText("Decrypt")
    testConditions()

#Browse files for an input file
def browseFiles():
    filename = QtGui.QFileDialog.getOpenFileName(Form,"Open File","/home/meerkat/Documents/Git Repos/FishFish/")
    #filename = "/home/meerkat/Documents/Git Repos/FishFish/Secret.txt" #<= Comment
    ui.txtInputfile.setText(filename)
    #ui.txtPassword.setText("Password") #<= Comment
    #Enc() #<= Comment

################################################################################

if __name__ == "__main__":
    import sys
    app = QtGui.QApplication(sys.argv)
    Form = QtGui.QWidget()
    ui = Ui_Form()
    ui.setupUi(Form)
    Form.show()
    sys.exit(app.exec_())
